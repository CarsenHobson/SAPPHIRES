import dash
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html
from dash import Input, Output, callback

app = dash.Dash(__name__, use_pages=True, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Callback to change the CSS class of "notification_flag"
@callback(
    Output("notification_flag", "className"),
    Input("interval-component", "n_intervals")
)
def change_css_class(n_intervals):
    class_options = ["intervention_status", "intervention_status-off"]
    return random.choice(class_options)

# Callback to control the "intervention_control" CSS class
@callback(
    Output("intervention_control", "className"),
    [
        Input("notification_flag", "n_clicks"),
        Input("intervention_control_close", "n_clicks"),
    ]
)
def update_output(n_clicks_notification, n_clicks_close):
    triggered_input = dash.callback_context.triggered[0]["prop_id"]
    if triggered_input == "notification_flag.n_clicks":
        new_class = "intervention_control"
        print("opened")
    else:
        new_class = "intervention_control-off"
        print("closed")
    return new_class

navbar = dbc.NavbarSimple(
    [
        dbc.Button("Current Conditions", href="/dashboard.py"),
        dbc.Button("Historical Conditions", href="/test.py"),
        dbc.Button("Information", href="/info.py")
    ])

app.layout = html.Div([
    html.Div([
        html.Button(
            html.Img(src="assets/img/status_fan.png", width="100%", height="100%"),
            id='notification_flag',
            className='intervention_status'
        ),
        dcc.Interval(id="interval-component", interval=10 * 1000, n_intervals=0)
    ]),
    html.Div([
        html.Div([
            html.H3("SAPPHIRES - Proactive Air Protection"),
            html.P("The SAPPHIRES system has detected potentially problematic air pollution conditions. "
                   "To help reduce the risks associated with this air pollution, we have automatically turned on a fan. "
                   "If you would rather not have the system on right now, you can snooze this automated feature for either the next 15 minutes, 60 minutes, or 4 hours."
            ),
        ]),
        html.Button("CLOSE", id='intervention_control_close'),
    ],
        id='intervention_control',
        className='intervention_control-off'
    ),
    html.Div([
        html.Div(
            dcc.Link(f"{page['name']}", href=page["path"], className='nav_button'),
            className='nav_block'
        )
        for page in dash.page_registry.values()
        if page["module"] != "pages.not_found_404"
    ],
        className="navbar_style"
    ),
    html.Hr(),
    dash.page_container,
])


if __name__ == "__main__":
    app.run_server(debug=False, host='0.0.0.0', port=8099)
