import dash
from dash import html, dcc
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from dash.dependencies import Input, Output
import random
import math
import dash_html_components as html

# Define custom CSS to add a drop shadow to the frame
custom_css = """
    .indicator-frame {
        box-shadow: 3px 3px 5px 0px rgba(0,0,0,0.75);
    }
"""


def calculate_aqi(pm25):
    if 0.0 <= pm25 <= 12.0:
        IHI, ILO, BPHI, BPLO = 50, 0, 12, 0
        return (0)
    elif 12.1 <= pm25 <= 35.4:
        IHI, ILO, BPHI, BPLO = 100, 51, 35.4, 12.1
        return (1)
    elif 35.5 <= pm25 <= 55.4:
        IHI, ILO, BPHI, BPLO = 150, 101, 55.4, 35.5
        return (2)
    elif 55.5 <= pm25 <= 150.4:
        IHI, ILO, BPHI, BPLO = 200, 151, 150.4, 55.5
        return (3)
    elif 150.5 <= pm25 <= 250.4:
        IHI, ILO, BPHI, BPLO = 300, 201, 250.4, 150.5
        return (4)
    elif pm25 >= 250.5:
        IHI, ILO, BPHI, BPLO = 500, 301, 500, 250.5
        return (5)
    else:
        return None  # Invalid PM2.5 value

    AQI = ((IHI - ILO) / (BPHI - BPLO)) * (pm25 - BPLO) + ILO
    return int(round(AQI))

# Create the initial figures
fig = go.Figure(go.Indicator(
    mode="gauge+delta+number",
    value=random.randint(0, 1000),
    domain={'x': [0, 1], 'y': [0, 1]},
    delta = {'reference': 0, 'relative': False, 'position' : "bottom"},
    number = {'valueformat':"math.log(f)"},
    gauge={
        'axis': {'range': [0, math.log(250)], 'tickwidth': 0, 'tickcolor': 'rgba(0,0,0,0)', 'showticklabels': False},
        'bar': {'color': "darkblue"},
        'bgcolor': "white",
        'borderwidth': 2,
        'bordercolor': "gray",
        'steps': [
            # {'range': [0, 12], 'color': 'green'},
            # {'range': [12, 35.4], 'color': 'yellow'},
            # {'range': [35.4, 55.4], 'color': 'orange'},
            # {'range': [55.4, 150.4], 'color': 'red'},
            # {'range': [150.4, 250.4], 'color': 'purple'},
            # {'range': [250.4, 400], 'color': 'maroon'}
        ]
    }
))

fig.add_annotation(
    text="Outdoor Particulate Matter Concentration  [\u03BCg/m\u00B3]",
    x=0.5,  # X-coordinate (center)
    y=-0.1,    # Y-coordinate (top)
    xref="paper",
    yref="paper",
    showarrow=False,
    font={'size': 18, 'color': 'darkblue'}
)

fig2 = go.Figure(go.Indicator(
    mode="gauge+number+delta",
    value=random.randint(0, 420),
    domain={'x': [0, 1], 'y': [0, 1]},
    gauge={
        'axis': {'range': [None, 500], 'tickwidth': 0, 'tickcolor': "darkblue"},
        'bar': {'color': "darkblue"},
        'bgcolor': "white",
        'borderwidth': 2,
        'bordercolor': "gray",
        'steps': [
            {'range': [0, 250], 'color': 'cyan'},
            {'range': [250, 400], 'color': 'royalblue'}
        ]
    }
))

fig2.add_annotation(
    text="Indoor Particulate Matter Concentration [\u03BCg/m\u00B3]",
    x=0.5,  # X-coordinate (center)
    y=-0.1,    # Y-coordinate (top)
    xref="paper",
    yref="paper",
    showarrow=False,
    font={'size': 18, 'color': 'darkblue'}
)

fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', font={'color': "darkblue", 'family': "Arial"})
fig2.update_layout(paper_bgcolor='rgba(0,0,0,0)', font={'color': "darkblue", 'family': "Arial"})

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

app.layout = dbc.Container(
    dbc.Row([
        dbc.Col(html.Div(
            [
                dcc.Graph(figure=fig, id='figure'),  # ID changed to 'figure'
                dcc.Interval(
                    id='interval-component-1',  # Unique ID
                    interval=1*5000,  # in milliseconds
                    n_intervals=0
                )
            ]
        ), width=6),
        dbc.Col(html.Div([
            dcc.Graph(figure=fig2, id='figure2'),  # ID changed to 'figure2'
            dcc.Interval(
                id='interval-component-2',  # Unique ID
                interval=1*5000,  # in milliseconds
                n_intervals=0
            )
        ]), width=6)
    ]),
)

# Define callback functions to update the figures
@app.callback(Output('figure', 'figure'), [Input('interval-component-1', 'n_intervals')])
def update_figure_1(n):
    fig.data[0].delta.reference = fig.data[0].value
    new_value = random.randint(1, 340)
    fig.data[0].value = new_value
    aqi = calculate_aqi(new_value)

    colors = gradient_colors = [
    'green', 'yellow', 'orange', 'red', 'purple', 'maroon']

    fig.data[0].gauge.bar.color = colors[aqi]

    range_upper = 6.2097 * (new_value ** 0.7053)
    fig.data[0].gauge.axis.range = (0, range_upper)
    return fig

@app.callback(Output('figure2', 'figure'), [Input('interval-component-2', 'n_intervals')])
def update_figure_2(n):
    new_value = random.randint(100, 420)
    fig2.data[0].value = new_value
    return fig2

# fig.add_shape(
#     type='rect',
#     x0=0,  # Adjust the x0 and x1 values for the desired shadow position
#     y0=0,  # Adjust the y0 and y1 values for the desired shadow position
#     x1=1,  # Adjust the x0 and x1 values for the desired shadow position
#     y1=0.05,  # Adjust the y0 and y1 values for the desired shadow height
#     line=dict(color='rgba(0,0,0,0)', width=0),  # Make the line transparent
#     fillcolor='rgba(0,0,0,0.2)'  # Adjust the alpha (last value) for shadow opacity
# )


if __name__ == "__main__":
    app.run_server(debug=True)

