import dash
from dash import html, dcc
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from dash.dependencies import Input, Output
import random
import math
import numpy as np

# Create the initial figures
plot_bgcolor = "#def"
quadrant_colors = [plot_bgcolor, "#f25829", "#f2a529", "#eff229", "#85e043", "#2bad4e"] 
quadrant_text = ["", "<b>Very high</b>", "<b>High</b>", "<b>Medium</b>", "<b>Low</b>", "<b>Very low</b"]
n_quadrants = len(quadrant_colors) - 1

value = 39
min_value = 0
max_value = 50
hand_length = np.sqrt(2) / 4
hand_angle = np.pi * (1 - (max(min_value, min(max_value, value)) - min_value) / (max_value - min_value))

fig = go.Figure(
    data=[
        go.Pie(
            values=[0.5] + (np.ones(n_quadrants) / 2 / n_quadrants).tolist(),
            rotation=90,
            hole=0.5,
            marker_colors=quadrant_colors,
            text=quadrant_text,
            textinfo="text",
            hoverinfo="skip",
        ),
    ],
    layout=go.Layout(
        showlegend=False,
        margin=dict(b=0,t=10,l=10,r=10),
        width=450,
        height=450,
        paper_bgcolor=plot_bgcolor,
        annotations=[
            go.layout.Annotation(
                text=f"<b>IOT sensor value:</b><br>{value} units",
                x=0.5, xanchor="center", xref="paper",
                y=0.25, yanchor="bottom", yref="paper",
                showarrow=False,
            )
        ],
        shapes=[
            go.layout.Shape(
                type="circle",
                x0=0.48, x1=0.52,
                y0=0.48, y1=0.52,
                fillcolor="#333",
                line_color="#333",
            ),
            go.layout.Shape(
                type="line",
                x0=0.5, x1=0.5 + hand_length * np.cos(np.pi * (1 - (max(min_value, min(max_value, value)) - min_value) / (max_value - min_value))),
                y0=0.5, y1=0.5 + hand_length * np.sin(np.pi * (1 - (max(min_value, min(max_value, value)) - min_value) / (max_value - min_value))),
                line=dict(color="#333", width=4)
            )
        ]
    )
)

fig.update_layout(paper_bgcolor="lavender", font={'color': "darkblue", 'family': "Arial"})

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

app.layout = dbc.Container(
    dbc.Row([
        dbc.Col(html.Div(
            [
                dcc.Graph(figure=fig, id='figure'),  # ID changed to 'figure'
                dcc.Interval(
                    id='interval-component-1',  # Unique ID
                    interval=1*1000,  # in milliseconds
                    n_intervals=0
                )
            ]
        ), width=6),
        dbc.Col(html.Div([]), width=6)
    ]),
)


@app.callback(Output('figure', 'figure'), [Input('interval-component-1', 'n_intervals')])
def update_figure_1(n):
    new_value = random.randint(10, 40)
    hand_angle = np.pi * (1 - (max(min_value, min(max_value, new_value)) - min_value) / (max_value - min_value))

    # Update the Pie chart values
    fig.data[0].values = [0.5] + (np.ones(n_quadrants) / 2 / n_quadrants).tolist()

    fig.layout.shapes[1].x1 = 0.5 + hand_length * np.cos(np.pi * (1 - (max(min_value, min(max_value, new_value)) - min_value) / (max_value - min_value)))
    fig.layout.shapes[1].y1 = 0.5 + hand_length * np.sin(np.pi * (1 - (max(min_value, min(max_value, new_value)) - min_value) / (max_value - min_value)))

    # Update the annotation text with the new value
    fig.layout.annotations[0].text = f"<b>IOT sensor value:</b><br>{new_value} units"

    return fig

if __name__ == "__main__":
    app.run_server(debug=True)
