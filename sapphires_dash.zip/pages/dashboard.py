import dash
from dash import html, dcc
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from dash import Dash, dcc, html, Input, Output, callback
import random
import math
from dash import html


dash.register_page(__name__, name='Current Conditions')


def calculate_aqi(pm25):
    if 0.0 <= pm25 <= 12.0:
        IHI, ILO, BPHI, BPLO = 50, 0, 12, 0
        return (0)
    elif 12.1 <= pm25 <= 35.4:
        IHI, ILO, BPHI, BPLO = 100, 51, 35.4, 12.1
        return (1)
    elif 35.5 <= pm25 <= 55.4:
        IHI, ILO, BPHI, BPLO = 150, 101, 55.4, 35.5
        return (2)
    elif 55.5 <= pm25 <= 150.4:
        IHI, ILO, BPHI, BPLO = 200, 151, 150.4, 55.5
        return (3)
    elif 150.5 <= pm25 <= 250.4:
        IHI, ILO, BPHI, BPLO = 300, 201, 250.4, 150.5
        return (4)
    elif pm25 >= 250.5:
        IHI, ILO, BPHI, BPLO = 500, 301, 500, 250.5
        return (5)
    else:
        return None  # Invalid PM2.5 value

    AQI = ((IHI - ILO) / (BPHI - BPLO)) * (pm25 - BPLO) + ILO
    return int(round(AQI))

# Create the initial figures
fig = go.Figure(go.Indicator(
    mode="gauge+delta+number",
    value=random.randint(0, 1000),
    domain={'x': [0, 1], 'y': [0, 1]},
    delta = {'reference': 0, 'relative': False, 'position' : "bottom"},
    number = {'valueformat':"math.log(f)"},
    gauge={
        'axis': {'range': [0, math.log(250)], 'tickwidth': 0, 'tickcolor': 'rgba(0,0,0,0)', 'showticklabels': False},
        'bar': {'color': "darkblue"},
        'bgcolor': "white",
        'borderwidth': 2,
        'bordercolor': "gray",
        'steps': []
    }
))


fig2 = go.Figure(go.Indicator(
    mode="gauge+delta+number",
    value=random.randint(0, 1000),
    domain={'x': [0, 1], 'y': [0, 1]},
    delta = {'reference': 0, 'relative': False, 'position' : "bottom"},
    number = {'valueformat':"math.log(f)"},
    gauge={
        'axis': {'range': [0, math.log(250)], 'tickwidth': 0, 'tickcolor': 'rgba(0,0,0,0)', 'showticklabels': False},
        'bar': {'color': "darkblue"},
        'bgcolor': "white",
        'borderwidth': 2,
        'bordercolor': "gray",
        'steps': []
    }
))

fig.add_annotation(
    text="Outdoor Particulate Matter Concentration  [\u03BCg/m\u00B3]",
    x=0.5,  # X-coordinate (center)
    y=-0.1,    # Y-coordinate (top)
    xref="paper",
    yref="paper",
    showarrow=False,
    font={'size': 12, 'color': 'darkblue'}
)

fig2.add_annotation(
    text="Indoor Particulate Matter Concentration [\u03BCg/m\u00B3]",
    x=0.5,  # X-coordinate (center)
    y=-0.1,    # Y-coordinate (top)
    xref="paper",
    yref="paper",
    showarrow=False,
    font={'size': 12, 'color': 'darkblue'}
)

fig.update_layout(
        margin={'t':0,'l':10,'b':20,'r':30},
        paper_bgcolor='rgba(0,0,0,0)',
        font={'color': "darkblue", 'family': "Arial"}
    )

fig2.update_layout(
        margin={'t':0,'l':10,'b':20,'r':30},
        paper_bgcolor='rgba(0,0,0,0)',
        font={'color': "darkblue", 'family': "Arial"}
    )

layout = dbc.Container(
    [
        dbc.Row([
            dbc.Col(html.Div(
                [
                    dcc.Graph(figure=fig, id='figure', style={'width': '47vw', 'height': '50vh'}, config={'displayModeBar': False}),
                    dcc.Interval(
                        id='interval-component-1',
                        interval=1 * 5000,
                        n_intervals=0
                    )
                ],
                className="pm_gauge"), width=6),
            dbc.Col(html.Div([
                dcc.Graph(figure=fig2, id='figure2', style={'width': '47vw', 'height': '50vh'}, config={'displayModeBar': False}),
                dcc.Interval(
                    id='interval-component-2',
                    interval=1 * 5000,
                    n_intervals=0
                )
            ], className="pm_gauge"), width=6)
        ]),
        dbc.Row([
            dbc.Col(html.Div([
                dbc.Row(
                    [
                    dbc.Col(html.Div([html.H3('Outdoor Temperature: '), html.Span('', id = 'out_temp_indicator', className = 'rt_indicator_span'), html.H3('°F')]), width = 6, className="rt_indicator")
                    ]),
                dbc.Row(
                    [
                    dbc.Col(html.Div([html.H3('Outdoor Humidity: '), html.Span('', id = 'out_rh_indicator', className = 'rt_indicator_span'), html.H3('%')]), width = 6, className="rt_indicator")
                    ])]
                , className=""), width=6),
            dbc.Col(html.Div([
                dbc.Row(
                    [
                    dbc.Col(html.Div([html.H3('Indoor Temperature: '), html.Span('', id = 'in_temp_indicator', className = 'rt_indicator_span'), html.H3('°F')]), width = 6, className="rt_indicator")
                    ]),
                dbc.Row(
                    [
                    dbc.Col(html.Div([html.H3('Indoor Humdity: '), html.Span('', id = 'in_rh_indicator', className = 'rt_indicator_span'), html.H3('%')]), width = 6, className="rt_indicator")
                    ])]
                , className=""), width=6)
        ])
    ]
)


# Define callback functions to update the figures
@callback(Output('figure', 'figure'), [Input('interval-component-1', 'n_intervals')])
def update_figure_1(n):
    fig.data[0].delta.reference = fig.data[0].value
    new_value = random.randint(1, 340)
    fig.data[0].value = new_value
    aqi = calculate_aqi(new_value)

    colors = gradient_colors = [
    'green', 'yellow', 'orange', 'red', 'purple', 'maroon']

    fig.data[0].gauge.bar.color = colors[aqi]

    range_upper = 6.2097 * (new_value ** 0.7053)
    fig.data[0].gauge.axis.range = (0, range_upper)


    return fig

@callback(Output('figure2', 'figure'), [Input('interval-component-2', 'n_intervals')])
def update_figure_2(n):
    fig2.data[0].delta.reference = fig2.data[0].value
    new_value = random.randint(1, 340)
    fig2.data[0].value = new_value
    aqi = calculate_aqi(new_value)

    colors = gradient_colors = [
    'green', 'yellow', 'orange', 'red', 'purple', 'maroon']

    fig2.data[0].gauge.bar.color = colors[aqi]

    range_upper = 6.2097 * (new_value ** 0.7053)
    fig2.data[0].gauge.axis.range = (0, range_upper)
    return fig2



@callback(Output('out_temp_indicator', 'children'), [Input('interval-component-1', 'n_intervals')])
def update_out_temp_indicator(n):
    new_temp = random.randint(0, 100)
    return f"{new_temp}"

@callback(Output('out_rh_indicator', 'children'), [Input('interval-component-1', 'n_intervals')])
def update_out_rh_indicator(n):
    new_rh = random.randint(0, 100)
    return f"{new_rh}"

@callback(Output('in_temp_indicator', 'children'), [Input('interval-component-1', 'n_intervals')])
def update_in_temp_indicator(n):
    new_temp = random.randint(0, 100)
    return f"{new_temp}"

@callback(Output('in_rh_indicator', 'children'), [Input('interval-component-1', 'n_intervals')])
def update_in_rh_indicator(n):
    new_rh = random.randint(0, 100)
    return f"{new_rh}"