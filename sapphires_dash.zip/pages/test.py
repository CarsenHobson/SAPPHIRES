import dash
from dash import dcc, html
import dash_bootstrap_components as dbc
from dash import Dash, dcc, html, Input, Output, callback
import plotly.graph_objs as go
import random
from datetime import datetime, timedelta

dash.register_page(__name__, name='Historical Conditions')

# Create random initial data
def generate_random_data():
    now = datetime.now()
    times = [now - timedelta(seconds=i) for i in range(100)]
    data1 = [random.randint(1, 100) for _ in range(100)]
    data2 = [random.randint(1, 100) for _ in range(100)]
    return times, data1, data2

times1, data1a, data1b = generate_random_data()
times2, data2a, data2b = generate_random_data()
times3, data3a, data3b = generate_random_data()

# Layout with three stacked time series plots
layout = html.Div([
    dbc.Row([
        dbc.Col(dcc.Graph(id='graph1', style={'height': '26vh'}, config={'displayModeBar': False}, className="pm_gauge"), width=11),
        dbc.Col(dcc.Graph(id='graph2', style={'height': '26vh'}, config={'displayModeBar': False}, className="pm_gauge"), width=11),
        dbc.Col(dcc.Graph(id='graph3', style={'height': '26vh'}, config={'displayModeBar': False}, className="pm_gauge"), width=11),
    ]),
    dcc.Interval(
        id='interval-component',
        interval=5*1000,  # Update every 5 seconds
        n_intervals=0
    )
])


# Callback to update the charts every 5 seconds
@callback(
    [Output('graph1', 'figure'),
     Output('graph2', 'figure'),
     Output('graph3', 'figure')],
    Input('interval-component', 'n_intervals')
)
def update_graphs(n):
    times1, data1a, data1b = generate_random_data()
    times2, data2a, data2b = generate_random_data()
    times3, data3a, data3b = generate_random_data()

    fig1 = go.Figure()
    fig1.add_trace(go.Scatter(x=times1, y=data1a, mode='lines', name='Data 1a'))
    fig1.add_trace(go.Scatter(x=times1, y=data1b, mode='lines', name='Data 1b'))
    fig1.update_layout(title='Particulate Matter Concentration [\u03BCg/m\u00B3]', xaxis_title='Time', yaxis_title='Value')

    fig2 = go.Figure()
    fig2.add_trace(go.Scatter(x=times2, y=data2a, mode='lines', name='Data 2a'))
    fig2.add_trace(go.Scatter(x=times2, y=data2b, mode='lines', name='Data 2b'))
    fig2.update_layout(title='Temperature °F', xaxis_title='Time', yaxis_title='Value')

    fig3 = go.Figure()
    fig3.add_trace(go.Scatter(x=times3, y=data3a, mode='lines', name='Data 3a'))
    fig3.add_trace(go.Scatter(x=times3, y=data3b, mode='lines', name='Data 3b'))
    fig3.update_layout(title='Relative Humidity %', xaxis_title='Time', yaxis_title='Value')

    fig1.update_layout(
        margin={'t':20,'l':0,'b':0,'r':0},
        xaxis_title='',
        yaxis_title='',
        title_font=dict(size=10)
    )

    fig2.update_layout(
        margin={'t':20,'l':0,'b':0,'r':0},
        xaxis_title='',
        yaxis_title='',
        title_font=dict(size=10)
    )

    fig3.update_layout(
        margin={'t':20,'l':0,'b':0,'r':0},
        xaxis_title='',
        yaxis_title='',
        title_font=dict(size=10)
    )

    return fig1, fig2, fig3

