import dash
import dash_html_components as html


dash.register_page(__name__, name='Information')

layout = html.Div(style={'width': '98vw', 'height': '75vh', 'display': 'flex'}, children=[
    html.Div(style={'flex': '1', 'background-color': 'lightblue', 'padding': '20px'}, children=[
        html.H1('Column 1', style={'color': 'blue'}),
        html.P('This is the content for column 1. It takes up 50% of the width and 100% of the height.'),
    ]),
    html.Div(style={'flex': '1', 'background-color': 'lightcoral', 'padding': '20px'}, children=[
        html.H1('Column 2', style={'color': 'red'}),
        html.P('This is the content for column 2. It also takes up 50% of the width and 100% of the height.'),
    ]),
])


